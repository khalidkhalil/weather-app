$( document ).ready(function() {
      $('select.selectpicker').on('show.bs.select', function (e) {
        alert('hello');
      });
		});